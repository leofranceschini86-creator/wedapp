import React, { useState } from 'react'

export default function Admin() {
  const [pass, setPass] = useState('')
  const [ok, setOk] = useState(false)

  const realPass = import.meta.env.VITE_ADMIN_PASS || 'admin1234'

  if (!ok) {
    return (
      <div style={{padding:20}}>
        <h1>Admin Login</h1>
        <input type="password" value={pass} onChange={e=>setPass(e.target.value)} />
        <button onClick={()=> setOk(pass===realPass)}>Entra</button>
      </div>
    )
  }

  return (
    <div style={{padding:20}}>
      <h1>Dashboard Admin</h1>
      <p>Qui potrai gestire abbonamenti e utenti.</p>
    </div>
  )
}