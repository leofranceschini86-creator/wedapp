# WedsApp v1

App demo stile WhatsApp con gestione clienti e pannello admin.

## Avvio locale
```bash
npm install
npm run dev
```

## Build produzione
```bash
npm run build
npm run preview
```
