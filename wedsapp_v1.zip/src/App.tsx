// src/App.tsx
// Inserire qui il codice completo fornito in precedenza (React + fakeApi + componenti)
export default function App() {
  return <h1>WedsApp è pronto 🚀</h1>;
}
